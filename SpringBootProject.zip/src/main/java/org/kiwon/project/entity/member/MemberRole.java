package org.kiwon.project.entity.member;

public enum MemberRole {

    USER,ADMIN //차례대로 0부터 시작하는 정수값이 자동으로 부여됨
}
